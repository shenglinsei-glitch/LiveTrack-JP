import React, { useMemo, useRef, useState } from 'react';
import { theme } from '../ui/theme';
import { GlassCard } from '../ui/GlassCard';
import { Artist, Concert, Exhibition, StatusItem } from '../domain/types';
import { generateStatusItems } from '../utils/statusGenerator';
import { TopCapsuleNav } from '../components/TopCapsuleNav';
import { getDueAction, parseConcertDate } from '../domain/logic';
import { TEXT } from '../ui/constants';
import { ConcertStatusCard } from '../components/ConcertStatusCard';
import { RemoteImage } from '../components/RemoteImage';

interface Props {
  artists: Artist[];
  exhibitions: Exhibition[];
  onOpenConcert: (aid: string, tid: string, cid: string) => void;
  onOpenConcertEditor: (aid: string, tid: string) => void;
  onUpdateConcert: (aid: string, tid: string, cid: string, updates: Partial<Concert>) => void;
  onOpenExhibitionDetail: (id: string) => void;
  onUpdateExhibitionStatus: (id: string, status: Exhibition['status']) => void;
  onExport: () => void;
  onImport: (data: any) => void;
}

type StatusTab = 'ALL' | 'CONCERT' | 'EXHIBITION';
type SectionKey = 'all' | 'pending' | 'decided' | 'history';
type SortKey = 'date_asc' | 'date_desc' | 'type' | 'status';

const formatCompactDate = (dateStr: string) => {
  if (!dateStr || dateStr === TEXT.GLOBAL.TBD) return '';
  const parts = dateStr.split(' ')[0].split('-');
  if (parts.length === 3) return `${parts[1]}/${parts[2]}`;
  return dateStr;
};

const getSectionLabel = (key: SectionKey) => {
  switch (key) {
    case 'pending':
      return '要確認';
    case 'decided':
      return '予定';
    case 'history':
      return '履歴';
    default:
      return '全部';
  }
};

const MENU_WIDTH = 300;

export const StatusPage: React.FC<Props> = ({
  artists,
  exhibitions,
  onOpenConcert,
  onOpenConcertEditor,
  onUpdateConcert,
  onOpenExhibitionDetail,
  onUpdateExhibitionStatus,
  onExport,
  onImport,
}) => {
  const [activeTab, setActiveTab] = useState<StatusTab>('ALL');
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [sectionFilter, setSectionFilter] = useState<SectionKey>('all');
  const [sortKey, setSortKey] = useState<SortKey>('date_asc');
  const importInputRef = useRef<HTMLInputElement>(null);

  const allItems = useMemo(() => generateStatusItems(artists, exhibitions) || [], [artists, exhibitions]);

  const filteredItems = useMemo(() => {
    if (activeTab === 'ALL') return allItems;
    if (activeTab === 'CONCERT') return allItems.filter((item) => item.type === 'concert');
    return allItems.filter((item) => item.type === 'exhibition');
  }, [allItems, activeTab]);

  const sections = useMemo(() => {
    const pending: StatusItem[] = [];
    const decided: StatusItem[] = [];
    const history: StatusItem[] = [];
    const now = new Date();

    filteredItems.forEach((item) => {
      if (item.type === 'exhibition') {
        if (item.status === 'PENDING') pending.push(item);
        else if (item.status === 'VISITED' || item.status === 'SKIPPED') history.push(item);
        else decided.push(item);
        return;
      }

      const concertDate = parseConcertDate(item.date, 'CONCERT');
      const isPassed = concertDate && now >= concertDate;
      const due = getDueAction(item.raw, now);

      if (due || ['発売前', '検討中', '抽選中'].includes(item.status)) pending.push(item);
      else if (item.status === '参戦済み' || (item.status === '見送' && isPassed)) history.push(item);
      else decided.push(item);
    });

    return { pending, decided, history };
  }, [filteredItems]);

  const sortItems = (items: StatusItem[]) => {
    const list = [...(items || [])];
    return list.sort((a, b) => {
      const da = parseConcertDate(a.date, a.type === 'concert' ? 'CONCERT' : 'EXHIBITION');
      const db = parseConcertDate(b.date, b.type === 'concert' ? 'CONCERT' : 'EXHIBITION');
      const ta = da ? da.getTime() : Number.MAX_SAFE_INTEGER;
      const tb = db ? db.getTime() : Number.MAX_SAFE_INTEGER;
      if (sortKey === 'date_desc') return tb - ta;
      if (sortKey === 'type') {
        if (a.type !== b.type) return a.type === 'concert' ? -1 : 1;
        return ta - tb;
      }
      if (sortKey === 'status') {
        const sa = `${a.type}-${a.status}`;
        const sb = `${b.type}-${b.status}`;
        return sa.localeCompare(sb) || ta - tb;
      }
      return ta - tb;
    });
  };

  const visibleSections = {
    pending: sectionFilter === 'all' || sectionFilter === 'pending' ? sortItems(sections.pending) : [],
    decided: sectionFilter === 'all' || sectionFilter === 'decided' ? sortItems(sections.decided) : [],
    history: sectionFilter === 'all' || sectionFilter === 'history' ? sortItems(sections.history) : [],
  };

  const handleImportFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const data = JSON.parse(event.target?.result as string);
        onImport(data);
        setIsMenuOpen(false);
      } catch (err) {
        console.error('Import parse failed:', err);
        window.alert('読み込みに失敗しました。JSON ファイルを確認してください。');
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const renderItem = (item: StatusItem) => {
    if (item.type === 'concert') {
      return (
        <ConcertStatusCard
          key={item.id}
          concert={item.raw}
          onClick={() => onOpenConcert(item.raw.artistId, item.raw.tourId, item.raw.concertId)}
          onUpdate={onUpdateConcert}
          onOpenEditor={() => onOpenConcertEditor(item.raw.artistId, item.raw.tourId)}
        />
      );
    }

    const statusColor = theme.colors.status[item.status as any] || theme.colors.primary;
    const imageId = Array.isArray(item.raw.imageIds) && item.raw.imageIds.length > 0 ? item.raw.imageIds[0] : undefined;

    return (
      <div key={item.id}>
        <GlassCard
          padding="12px 16px"
          style={{ marginBottom: item.status === 'PENDING' ? '4px' : '12px', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '12px' }}
          onClick={() => onOpenExhibitionDetail(item.parentId)}
        >
          <div style={{ width: '40px', height: '40px', borderRadius: '12px', background: 'rgba(0,0,0,0.05)', overflow: 'hidden', flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <RemoteImage
              imageUrl={item.raw.imageUrl}
              imageId={imageId}
              alt={item.title}
              style={{ width: '100%', height: '100%', objectFit: 'cover' }}
              fallback={<span style={{ fontSize: '18px', opacity: 0.35 }}>{item.actionType === 'exhibition_start' ? '🖼️' : '🏁'}</span>}
            />
          </div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2px' }}>
              <span style={{ fontSize: '11px', fontWeight: '700', color: theme.colors.textSecondary, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{item.title}</span>
              <span style={{ fontSize: '11px', fontWeight: '800', color: statusColor }}>{item.displayStatus}</span>
            </div>
            <div style={{ fontSize: '14px', fontWeight: '800', color: theme.colors.text, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
              {item.raw.venueName || item.raw.venue || item.title}
            </div>
          </div>
          <div style={{ textAlign: 'right', flexShrink: 0 }}>
            <div style={{ fontSize: '13px', fontWeight: '900', color: theme.colors.text }}>{formatCompactDate(item.date)}</div>
            <div style={{ fontSize: '10px', fontWeight: '700', color: theme.colors.textSecondary }}>{item.date.split(' ')[1] || ''}</div>
          </div>
        </GlassCard>

        {item.status === 'PENDING' && (
          <div style={{ display: 'flex', gap: '8px', marginBottom: '16px', padding: '0 4px' }}>
            {item.actionType === 'exhibition_start' ? (
              <>
                <button onClick={(e) => { e.stopPropagation(); onUpdateExhibitionStatus(item.parentId, 'PLANNED'); }} style={actionPrimaryBtn}>参加</button>
                <button onClick={(e) => { e.stopPropagation(); onUpdateExhibitionStatus(item.parentId, 'SKIPPED'); }} style={actionGhostBtn}>不参加</button>
              </>
            ) : (
              <>
                <button onClick={(e) => { e.stopPropagation(); onUpdateExhibitionStatus(item.parentId, 'VISITED'); }} style={actionPrimaryBtn}>参加済み</button>
                <button onClick={(e) => { e.stopPropagation(); onUpdateExhibitionStatus(item.parentId, 'SKIPPED'); }} style={actionGhostBtn}>未参加</button>
              </>
            )}
          </div>
        )}
      </div>
    );
  };

  const renderSection = (title: string, items: StatusItem[]) => {
    if (!items.length) return null;
    return (
      <div style={{ marginBottom: '24px' }}>
        <h3 style={{ fontSize: '13px', fontWeight: '900', color: theme.colors.textSecondary, marginBottom: '12px', paddingLeft: '4px', letterSpacing: '0.02em' }}>
          {title} ({items.length})
        </h3>
        {items.map(renderItem)}
      </div>
    );
  };

  const tabs = [
    { key: 'ALL', label: '全部' },
    { key: 'CONCERT', label: '公演' },
    { key: 'EXHIBITION', label: '展覧' },
  ];

  const leftControl = (
    <button
      onClick={() => setIsMenuOpen((v) => !v)}
      style={{ width: '44px', height: '44px', borderRadius: '9999px', background: 'rgba(255,255,255,0.72)', backdropFilter: 'blur(16px)', WebkitBackdropFilter: 'blur(16px)', border: '1px solid rgba(15, 23, 42, 0.06)', boxShadow: '0 6px 18px rgba(15, 23, 42, 0.06)', color: '#9CA3AF', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}
      aria-label="status tools"
    >
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <line x1="4" y1="21" x2="4" y2="14" /><line x1="4" y1="10" x2="4" y2="3" /><line x1="12" y1="21" x2="12" y2="12" /><line x1="12" y1="8" x2="12" y2="3" /><line x1="20" y1="21" x2="20" y2="16" /><line x1="20" y1="12" x2="20" y2="3" /><line x1="1" y1="14" x2="7" y2="14" /><line x1="9" y1="8" x2="15" y2="8" /><line x1="17" y1="16" x2="23" y2="16" />
      </svg>
    </button>
  );

  return (
    <div style={{ paddingTop: 'calc(12px + env(safe-area-inset-top) + 44px + 16px)', minHeight: '100vh', background: theme.colors.background }}>
      <TopCapsuleNav activeTab={activeTab} onTabChange={(tab) => setActiveTab(tab as StatusTab)} onRefresh={() => {}} tabs={tabs} leftControl={leftControl} rightControl={<div />} />

      {isMenuOpen && (
        <div style={{ position: 'fixed', inset: 0, zIndex: 120 }} onClick={() => setIsMenuOpen(false)}>
          <GlassCard
            className="fade-in"
            style={{
              position: 'fixed',
              top: 'calc(12px + env(safe-area-inset-top) + 52px)',
              left: '16px',
              width: `${MENU_WIDTH}px`,
              maxWidth: 'calc(100vw - 32px)',
            }}
          >
            <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }} onClick={(e) => e.stopPropagation()}>
              <section>
                <div style={sectionTitle}>並び替え</div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                  <MenuItem label="日付近い順" active={sortKey === 'date_asc'} onClick={() => setSortKey('date_asc')} />
                  <MenuItem label="日付遠い順" active={sortKey === 'date_desc'} onClick={() => setSortKey('date_desc')} />
                  <MenuItem label="種別優先" active={sortKey === 'type'} onClick={() => setSortKey('type')} />
                  <MenuItem label="状態優先" active={sortKey === 'status'} onClick={() => setSortKey('status')} />
                </div>
              </section>

              <section style={{ borderTop: '0.5px solid rgba(0,0,0,0.1)', paddingTop: 16 }}>
                <div style={sectionTitle}>セクション絞り込み</div>
                <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                  {(['all', 'pending', 'decided', 'history'] as SectionKey[]).map((key) => (
                    <SmallChip key={key} label={getSectionLabel(key)} active={sectionFilter === key} onClick={() => setSectionFilter(key)} />
                  ))}
                </div>
              </section>

              <section style={{ borderTop: '0.5px solid rgba(0,0,0,0.1)', paddingTop: 16 }}>
                <div style={sectionTitle}>データ</div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                  <MenuItem label="データを書き出す" onClick={() => { onExport(); setIsMenuOpen(false); }} />
                  <MenuItem label="データを読み込む" onClick={() => importInputRef.current?.click()} />
                </div>
                <input ref={importInputRef} type="file" accept=".json,application/json" style={{ display: 'none' }} onChange={handleImportFileChange} />
              </section>
            </div>
          </GlassCard>
        </div>
      )}

      <div style={{ padding: '0 16px 140px' }}>
        {renderSection(getSectionLabel('pending'), visibleSections.pending)}
        {renderSection(getSectionLabel('decided'), visibleSections.decided)}
        {renderSection(getSectionLabel('history'), visibleSections.history)}
      </div>
    </div>
  );
};

const sectionTitle: React.CSSProperties = {
  fontSize: '12px',
  color: theme.colors.textSecondary,
  marginBottom: 8,
  fontWeight: 'bold',
};

const menuButtonBase: React.CSSProperties = {
  width: '100%',
  textAlign: 'left',
  padding: '10px 12px',
  borderRadius: '12px',
  border: 'none',
  fontSize: '14px',
  fontWeight: 600,
  cursor: 'pointer',
  transition: 'all 0.2s',
  background: 'transparent',
  color: theme.colors.text,
};

const MenuItem: React.FC<{ label: string; active?: boolean; onClick: () => void }> = ({ label, active = false, onClick }) => (
  <button onClick={onClick} style={{ ...menuButtonBase, background: active ? 'rgba(83, 190, 232, 0.10)' : 'transparent', color: active ? theme.colors.primary : theme.colors.text, fontWeight: active ? 800 : 600 }}>
    {label}
  </button>
);

const SmallChip: React.FC<{ label: string; active: boolean; onClick: () => void }> = ({ label, active, onClick }) => (
  <button
    onClick={onClick}
    style={{
      border: 'none',
      cursor: 'pointer',
      padding: '6px 10px',
      fontSize: 12,
      fontWeight: 800,
      borderRadius: 999,
      background: active ? 'rgba(83, 190, 232, 0.16)' : 'rgba(0,0,0,0.04)',
      color: active ? theme.colors.primary : theme.colors.textSecondary,
      whiteSpace: 'nowrap',
    }}
  >
    {label}
  </button>
);

const actionPrimaryBtn: React.CSSProperties = {
  flex: 1,
  border: 'none',
  borderRadius: 12,
  background: theme.colors.primary,
  color: 'white',
  padding: '12px 16px',
  fontSize: 13,
  fontWeight: 900,
  cursor: 'pointer',
};

const actionGhostBtn: React.CSSProperties = {
  ...actionPrimaryBtn,
  background: 'rgba(0,0,0,0.06)',
  color: theme.colors.text,
};
